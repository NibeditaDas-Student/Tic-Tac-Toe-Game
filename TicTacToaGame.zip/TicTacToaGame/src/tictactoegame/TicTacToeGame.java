/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tictactoegame;

/**
 *
 * @author Nibedita
 */
public class TicTacToeGame
{
    public static void main(String[] args)
    {
        new UserPanel();
    }
}
